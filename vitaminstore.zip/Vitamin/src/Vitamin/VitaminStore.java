/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vitamin;

///////////////////////////////////////////////////////////////////////////////
//
// @author Joe Waldron 
// Hold info related to a single Vitamin Store that sells "super wonder 
// vitamins".  These vitamins do it all (increase stamina, improve circulation,
// give you clear skin, increase energy, make you more attentive, allow you
// to sleep better, etc.)  
// Keeps track of inventory, number of bottles sold, profits, etc.
//
///////////////////////////////////////////////////////////////////////////////

public class VitaminStore {
    
    ///////////////////////////////////////////////////////////////////////////
    //  Constants
    ///////////////////////////////////////////////////////////////////////////
    /**
     * number of bottles in a batch
     */
    private static final int BATCHSIZE = 25;
    /**
     * number of pills in a bottle
     */
    private static final int PILLSINBOTTLE = 100;
    
    ///////////////////////////////////////////////////////////////////////////
    //  Instance Variables
    ///////////////////////////////////////////////////////////////////////////
    /**
     * price a bottle of vitamins is sold for
     */
    private double retailPrice = 20.0;
    /**
     * price paid to manufacturer for one bottle of vitamins
     */
    private double wholesaleCost = 7.50;
    /**
     * number of bottles currently in stock
     */
    private int currInventory = 0;
    /**
     * number of bottles sold since start
     */
    private int totalSold = 0;
    
    ///////////////////////////////////////////////////////////////////////////
    //  Constructors
    ///////////////////////////////////////////////////////////////////////////
    
    /**
     * Creates a default instance of VitaminStore with all default values
     */
    public VitaminStore() {
    }
    /**
     * Creates a new instance of VitaminStore using provided retail price
     * and wholesale cost
     * @param ret the retail price of a bottle of vitamins
     * @param whole the wholesale price of a bottle of vitamins
     */
    public VitaminStore(double ret, double whole) {
        retailPrice = ret; 
        wholesaleCost = whole;
    }
    /**
     * Creates a new instance of VitaminStore using provided retail price,
     * wholesale cost, and initial inventory
     * @param ret the retail price of a bottle of vitamins
     * @param whole the wholesale price of a bottle of vitamins
     * @param inv the value of the initial inventory
     */
    public VitaminStore(double ret, double whole, int inv) {
        retailPrice = ret; 
        wholesaleCost = whole;
        currInventory = inv;
    }
    /** 
     * Creates a new instance of VitaminStore using provided retail price,
     * wholesale cost, initial inventory (in bottles), and number of bottles 
     * sold
     * @param ret the retail price of a bottle of vitamins
     * @param whole the wholesale price of a bottle of vitamins
     * @param inv the value of the initial inventory
     * @param sold the number of bottles of vitamins sold
     */
    public VitaminStore(double ret, double whole, int inv, int sold) {
        retailPrice = ret;  
        wholesaleCost = whole;
        currInventory = inv;
        totalSold = sold;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //  Inspectors
    ///////////////////////////////////////////////////////////////////////////
    
    /**
     * obtain the retail price of the product being tracked
     * @return retail price of a bottle of vitamins
     */
    public double getRetailPrice () {
        return retailPrice;
    }
     
    /**
     * obtain the wholesale  cost of the product being tracked
     * @return wholesale price of a bottle of vitamins
     */
    public double getWholesaleCost () {
        return wholesaleCost;
    }
    
    /**
     * obtain the current inventory
     * @return number of bottles in inventory
     */
    public int getCurrInventory () {
        return currInventory;
    }
    
    /**
     * obtain the current number sold
     * @return number of bottles sold since the start of the program running
     */
    public int getTotalSold () {
        return totalSold;
    }
    
    /**
     * obtain the batch size
     * @return number of bottles in a batch
     */
    public int getBatchSize() {
        return BATCHSIZE;
    }
    ///////////////////////////////////////////////////////////////////////////
    //  Psuedo Inspectors
    ///////////////////////////////////////////////////////////////////////////
    
    /**
     * obtain the total number of pills sold based on number of bottles sold
     * @return total number of bottles sold multiplied by number of pills per 
     * bottle
     */
    public int getPillsSold () {
        return (totalSold * PILLSINBOTTLE);
    }
    /**
     * obtain the profit margin - amount of profit for selling one item)
     * @return difference between retail and wholesale price of a bottle 
     */
    public double getProfitMargin () {
        return retailPrice - wholesaleCost;
    }
    /**
     * obtain the number stocked (sold or unsold)
     * @return number of bottles sold plus number of bottles in inventory 
     */
    public int getTotalStocked () {
        return totalSold + currInventory;
    }
    
    /**
     * obtain the total number of pills in inventory
     * @return bottle inventory multiplied by number of pills per bottle
     */
    public int getPillsInventory () {
        return (currInventory * PILLSINBOTTLE);
    }
    
    /**
     * obtain the cost of current inventory 
     * @return the number of bottles in inventory multiplied by the wholesale 
     * cost of each bottle
     */
    public double getValueOfInventory ()  {        
            return currInventory * this.getWholesaleCost();
    }
    
    
    /**
     * obtain the cost of goods sold (for accountants)
     * @return the number of bottles sold multiplied by the wholesale cost of 
     * each bottle
     */
    public double getCostOfGoodsSold ()  {
            return totalSold * this.getWholesaleCost();
    }    
    /**
     * obtain the cost of all goods stocked (sold and unsold)
     * @return sum of inventory costs plus cost of goods sold
     */
    public double getCostOfGoodsStocked () {
        return this.getValueOfInventory() + this.getCostOfGoodsSold();
            }
    /**
     * obtain the revenues brought in
     * @return bottles sold multiplied by retail cost of each bottle
     */
    public double getRevenues ()  {
            return totalSold * this.getRetailPrice();
    }
    
    
    /**
     * obtain the profits earned
     * @return number of bottles sold multiplied by profit per bottle
     */
    public double getProfit ()  {
            return totalSold * this.getProfitMargin();
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //  Mutators
    ///////////////////////////////////////////////////////////////////////////
    
    ///////////////////////////////////////////////////////////////////////////
    //  Controlled Mutators
    ///////////////////////////////////////////////////////////////////////////
    /**
     * a customer buys a number of bottles of vitamins
     * @param number number of bottles customer purchases
     * @return true if purchase is possible, otherwise false
     */
    public boolean buy (int number) {
        if ((number > 0) && (number <= currInventory)) {
            // can sell that many 
            totalSold += number;
            currInventory -= number;
            return true;
        }
        else {
            return false;
            
        }
    }
    
    /**
     * the company buys more inventory from the manufacturer
     * @param number number of bottles by which to increase inventory
     * @return true if number is positive and inventory can be increased, 
     * otherwise false
     */
    public boolean addInventory (int number) {
        if (number > 0)  {
            // only add positive
            currInventory += number;
            return true;
        }
        else {
            return false;
            
        }
    }
    
    /**
     * Company buys more batches of inventory from the manufacturer
     * @param numBatches the number of batches, where each batch consists
     * of multiple bottles
     * @return true if numberBatch is positive and inventory can be increased, 
     * otherwise false
     */
    public boolean addInventoryBatch (int numBatches) {
        if (numBatches > 0)  {
            // only add positive
            currInventory += numBatches * this.BATCHSIZE;
            return true;
        }
        else {
            return false;
            
        }        
    }
    
    /**
     * Company buys one batch from the manufacturer
     * @return true if numberBatch is positive and inventory can be increased, 
     * otherwise false
     */
    public boolean addInventoryBatch () { 
        return this.addInventoryBatch(1);
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //  Override Methods for Vitamin objects
    ///////////////////////////////////////////////////////////////////////////
    
    /** 
     * create a string representation for the PizzaStore object
     * @return 
     */
    @Override 
    public String toString () {
        String res = "";
        res += " Price: " + this.retailPrice;
        res += " Cost: " + this.wholesaleCost;
        res += " Inv: " + this.currInventory;
        res += " Sold: " + this.totalSold;
        res += " Revenues: " + this.getRevenues();
        res += " Profit: " + this.getProfit();
        return res;
    }
    
    /** 
     * report whether passed object is completely equal in contents to invoking 
     * object
     * @param toCompare a VitaminStore object
     * @return 
     */
    @Override 
    public boolean equals (Object toCompare) { 
        if (toCompare instanceof VitaminStore) {
            VitaminStore other = (VitaminStore) toCompare;
            if ((this.retailPrice == other.retailPrice)
                    && (this.wholesaleCost == other.wholesaleCost)
                && (this.currInventory == other.currInventory)
                && (this.totalSold == other.totalSold) ) { 
                return true;
            }
            else {
                // not all equal
                return false;
            }
        }
        else {
            // if not same type cannot be equal
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + (int) (Double.doubleToLongBits(this.retailPrice) ^ (Double.doubleToLongBits(this.retailPrice) >>> 32));
        hash = 97 * hash + (int) (Double.doubleToLongBits(this.wholesaleCost) ^ (Double.doubleToLongBits(this.wholesaleCost) >>> 32));
        hash = 97 * hash + this.currInventory;
        hash = 97 * hash + this.totalSold;
        return hash;
    }
}
