/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vitamin;

import java.net.URL;
import java.text.NumberFormat;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType; 
import java.util.*; 

/**
 * FXML Controller class
 *
 * @author gutierresk1
 */
// Hello! This program will help the buyers order bottles of Vitamins. We use the program to provide services

public class FXMLLab4Controller implements Initializable {
    @FXML
    private TextField txtBottles;
    @FXML
    private Button btnBuys;
    @FXML
    private TextField txtBatches;
    @FXML
    private Button btnOrders;
    @FXML
    private Button btnRestart;
    @FXML
    private Button btnShow;
    @FXML
    private Button btnHide;
    @FXML
    private Button btnQuit;
    @FXML
    private Pane paneResults;
    @FXML
    private Label lblPrice;
    @FXML
    private Label lblCost;
    @FXML
    private Label lblMargin;
    @FXML
    private Label lblBottles;
    @FXML
    private Label lblPills;
    @FXML
    private Label lblRevenues;
    @FXML
    private Label lblProfit;
    @FXML
    private Label lblInvenBottles;
    @FXML
    private Label lblInvenPills;
    @FXML
    private Label lblCostInven;
    @FXML
    private Label lblTextResult;

    
    Alert alert = new Alert(AlertType.INFORMATION);   
    Locale locale = new Locale("en", "US"); 
    NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(locale);
    
    VitaminStore newStore;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
          paneResults.setVisible(false);
          lblTextResult.setVisible(false);
          // This code will allow the result pane to be invisible
          newStore = new VitaminStore();
          
          alert.setTitle("Information Dialog");  
          alert.setHeaderText(null);    
    }    
    @FXML
    private void handleButtonActionBuy(ActionEvent event) {
        //inventory bottles 
        int inventory = newStore.getCurrInventory();
        String userOrder = txtBottles.getText();
        boolean sold =  true; 
        if(inventory > 0){
            alert.setContentText("sold? "+ sold);
            alert.showAndWait();
        // I used boolean for this part. If input of batches is in, and the number of bottles is < than batches. The code return true.     
            int orderNum = Integer.parseInt(userOrder);
            newStore.buy(orderNum);
            
            double revenue = newStore.getRevenues(); 
            double profit = newStore.getProfit();
        //  Just formula for revenue and profit.
            lblBottles.setText(""+ newStore.getTotalSold());
            lblPills.setText(""+newStore.getPillsSold());
            
            lblRevenues.setText(currencyFormatter.format(revenue));
            lblProfit.setText(currencyFormatter.format(profit)); 
            
            lblInvenBottles.setText(""+newStore.getCurrInventory());
            lblInvenPills.setText(""+newStore.getPillsInventory());
            
             lblCostInven.setText(currencyFormatter.format(newStore.getValueOfInventory()));
       // The code used method from the extended class to put text on the label
        }else{
           
            sold = false;
            alert.setContentText("sold? "+ sold);
            alert.showAndWait();
         // A customer cannot buy if we do not have it in stock.
         // If no value add in "number of bottles", the program will return false
       
        }
    }

    @FXML
    private void HandleButtonActionOrder(ActionEvent event) {
        String userBatches = txtBatches.getText();
        alert.setContentText("restocked with "+userBatches+" batches");
        alert.showAndWait();
         
        int batchNum = Integer.parseInt(userBatches);
        newStore.addInventoryBatch(batchNum);
        
        lblInvenBottles.setText(""+newStore.getCurrInventory());
        lblInvenPills.setText(""+newStore.getPillsInventory());
    }

    @FXML
    private void handleButtonActionRestart(ActionEvent event) {
        newStore = new VitaminStore(20.0,7.5, 0,0);
        
        lblPrice.setText(currencyFormatter.format(newStore.getRetailPrice()));
        lblCost.setText(currencyFormatter.format(newStore.getWholesaleCost()));
        lblMargin.setText(currencyFormatter.format(newStore.getProfitMargin()));
        lblBottles.setText(""+newStore.getCurrInventory());
        lblPills.setText(""+newStore.getPillsInventory());
        lblRevenues.setText(currencyFormatter.format(newStore.getRevenues()));
        lblProfit.setText(currencyFormatter.format(newStore.getProfit())); 
        lblInvenBottles.setText(""+newStore.getCurrInventory());
        lblInvenPills.setText(""+newStore.getPillsInventory());
        lblCostInven.setText(currencyFormatter.format(newStore.getValueOfInventory()));
    }
// There is nothing much going on. The main code is what you wrote in VitaminStore.java.
// I grab the code in the extended class and use set Text on the label. 
    @FXML
    private void handleButtonActionShow(ActionEvent event) {
        paneResults.setVisible(true);
        lblTextResult.setVisible(true);
    }
// the code will make the pane visible when you click on the Show button.
    @FXML
    private void handleButtonActionHide(ActionEvent event) {
        paneResults.setVisible(false);
        lblTextResult.setVisible(false);
    }
// So when you click on Hide, the pane will become invisible
    @FXML
    private void buttonActionHandleQuit(ActionEvent event) {
      System.exit(0);
// The code exit the program
    }
}
